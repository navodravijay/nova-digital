#!/usr/bin/env python3
"""Safely inject NV. FACE LAB card into an existing static index.html.
Only run against an up-to-date local checkout of the main site.
Creates index.html.bak before edits and will refuse on unexpected markup.
"""
from pathlib import Path
import sys
import shutil

if len(sys.argv) != 2:
    raise SystemExit('Usage: python insert_portfolio_card.py /path/to/main-website-folder')
repo = Path(sys.argv[1]).resolve()
index = repo / 'index.html'
if not index.is_file():
    raise SystemExit('ERROR: index.html not found at repository root. No changes made.')
html = index.read_text(encoding='utf-8')
if 'id="nv-face-lab-project"' in html:
    raise SystemExit('Already installed. No changes made.')
if 'id="portfolio"' not in html and "id='portfolio'" not in html:
    raise SystemExit('ERROR: Cannot locate portfolio section. No changes made.')
# Designed for the known NV SHARP SOLUTIONS portfolio markup only.
anchor='<div class="nv-work-outro reveal">'
if html.count(anchor) != 1:
    raise SystemExit('ERROR: Portfolio insertion point not found exactly once; provide the current ZIP for manual integration.')
if '</head>' not in html:
    raise SystemExit('ERROR: Head insertion point missing. No changes made.')
css_href='assets/css/nv-face-lab-portfolio.css'
if css_href not in html:
    html=html.replace('</head>',f'  <link rel="stylesheet" href="{css_href}">\n</head>',1)
card=(Path(__file__).parent/'portfolio-card.html').read_text(encoding='utf-8')
html=html.replace(anchor,card+'\n    '+anchor,1)
image_dest=repo/'Images'/'nv-face-lab-v25.webp'
css_dest=repo/'assets'/'css'/'nv-face-lab-portfolio.css'
for f in [image_dest,css_dest]:
    if f.exists():
        raise SystemExit(f'ERROR: {f} already exists. No changes made.')
shutil.copy2(index,repo/'index.html.bak')
image_dest.parent.mkdir(parents=True,exist_ok=True)
css_dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(Path(__file__).parent/'Images'/'nv-face-lab-v25.webp',image_dest)
shutil.copy2(Path(__file__).parent/'assets'/'css'/'nv-face-lab-portfolio.css',css_dest)
index.write_text(html,encoding='utf-8')
print('Inserted portfolio card. Review diffs and tests before committing.')
print('Do NOT upload index.html.bak to GitHub.')
