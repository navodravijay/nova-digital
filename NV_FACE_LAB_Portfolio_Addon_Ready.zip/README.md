# NV. FACE LAB — portfolio add-on (not yet installed)

This package adds a single **in-house** computer-vision project card to the NV SHARP SOLUTIONS portfolio. It contains a real screenshot from the V2.5 website supplied in the conversation (not an AI-created fake client project), an accessible project description, and real live demo/GitHub links.

## Files
- `portfolio-card.html`: HTML component to insert within the portfolio section.
- `assets/css/nv-face-lab-portfolio.css`: CSS scoped entirely under `.nvfl-...` classes.
- `Images/nv-face-lab-v25.webp`: optimized screenshot thumbnail.
- `insert_portfolio_card.py`: optional fail-closed script to insert into known `nv-work-outro` portfolio markup. Requires Python 3.

## Important — protect the live site
1. Download the **latest** `navodravijay/nova-digital` code as a ZIP or git pull in a local working folder. Do not use an older source snapshot.
2. Make a feature branch, e.g. `feature/add-nv-face-lab-portfolio` from the real configured production branch.
3. Check the site's actual markup. If the portfolio uses `<div class="nv-work-outro reveal">`, the script can be run as `python insert_portfolio_card.py PATH_TO_MAIN_SITE`. If the layout has changed, do not force the script — get a manual integration.
4. Verify `index.html` is at your Cloudflare static output root. Review the changed files, screenshot, existing portfolio items, pricing, contact/WhatsApp functionality, responsive layout, all links, and CSP headers. Keep existing `_headers` in place; the local CSS and image are first-party assets.
5. Commit the exact changed `index.html`, local CSS and image only. Do **not** upload `index.html.bak`. Use a GitHub PR and Cloudflare Preview. Merge to the production branch only after tests.

## Links and claims
- Live demo: https://nv-face-lab.pages.dev/
- Source: https://github.com/navodravijay/nv-face-lab
- Developer: Navod Ravindu Jayaweera
- No claims of audited or 100% secure code.

The component has not been added to the actual GitHub repository; a live deployment has not been performed. Automated content and CSS checks do not substitute for testing the user's real up-to-date source.
